package empresa;

public class MoedaInexistenteException extends Exception{
}
