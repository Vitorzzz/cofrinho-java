package empresa;

public class MenuAdicionarMoeda {
    public static void exibir()
    {
        System.out.println("SELECAO DE MOEDAS");
        System.out.println("[1] Dolar.");
        System.out.println("[2] Euro.");
        System.out.println("[3] Real.");
        System.out.println("[0] Cancelar adição.");
        System.out.print("Escolha uma Opcao: ");

        switch(Principal.ENTRADA.nextInt())
        {
            case 1 :
                adicionarDolar();
                break;

            case 2 :
                adicionarEuro();
                break;

            case 3 :
                adicionarReal();
                break;

            case 0 :
                break;

            default :
                System.out.println("Opcao invalida.");
        }
    }

    private static void adicionarMoeda(int[] valoresPossiveis, String nome)
    {
        String valores = "";
        int valor;

        for(int valorPossivel : valoresPossiveis)
        {
            valores +=valorPossivel + " ";
        }

        System.out.println("Valores Disponíves Para " + nome);
        System.out.println(valores);
        System.out.println();
        System.out.print("Digite o valor a ser adicionado ou 0(zero) para cancelar: ");

        valor = Principal.ENTRADA.nextInt();

        if(valor == 0)
        {
            return;
        }

        System.out.println();

        try
        {
            switch (nome)
            {
                case Dolar.NOME :
                    Principal.COFRINHO.adicionar(new Dolar(valor));
                break;

                case Euro.NOME :
                    Principal.COFRINHO.adicionar(new Euro(valor));
                break;

                case Real.NOME :
                    Principal.COFRINHO.adicionar(new Real(valor));
                break;


            }

            System.out.println("Voce colocou "+ valor + " centavo(s) no cofrinho.");
        }
        catch(MoedaInexistenteException ex)
        {
            System.out.println("Nao foi possivel adicionar "  + valor + ", pois, não existe essa moeda.");
        }
    }

    private static void adicionarDolar()
    {
        adicionarMoeda(Dolar.VALORES_POSSIVEIS, Dolar.NOME);
    }

    private static void adicionarEuro()
    {
        adicionarMoeda(Euro.VALORES_POSSIVEIS, Euro.NOME);
    }

    private static void adicionarReal()
    {
        adicionarMoeda(Real.VALORES_POSSIVEIS, Real.NOME); }
    
}

  

